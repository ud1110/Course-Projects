#include <iostream>
#include <fstream>
using namespace std;
float LIUl(float P){
    float Ul;
    if(P>=700 && P<=750){
        Ul = 526.3+0.2429*P;
    }
    else if(P>=750 && P<=800){
        Ul=0.2309*P+535.3;
    }
    else if(P>=800 && P<=850){
        Ul=0.2209*P+543.3;
    }
    else if(P>=850 && P<=900){
        Ul=0.2109*P+551.8;
    }
    else if(P>=900 && P<=950){
        Ul=0.2029*P+559.0;
    }
    else if(P>=950 && P<=1000){
        Ul = 0.1949*P+566.6;
    }
    return Ul;
}
float LIUv(float P){
    float Uv;
    if(P>=700 && P<=750){
        Uv = 0.057*P+2531.0;
    }
    else if(P>=750 && P<=800){
        Uv=0.045*P+2540.0;
    }
    else if(P>=800 && P<=850){
        Uv=-0.013*P+2586.4;
    }
    else if(P>=850 && P<=900){
        Uv=0.063*P+2521.8;
    }
    else if(P>=900 && P<=950){
        Uv=0.034*P+2547.9;
    }
    else if(P>=950 && P<=1000){
        Uv=0.036*P+2546;
    }
    return Uv;
}
float LIVl(float P){
    float Vl=0.0011;
    return Vl;
}
float LIVv(float P){
    float Vv;
    if(P>=700 && P<=750){
        Vv=-0.00036*P+0.525;
    }
    else if(P>=750 && P<=800){
        Vv=-0.0003*P+0.48;
    }
    else if(P>=800 && P<=850){
        Vv=-0.00022*P+0.416;
    }
    else if(P>=850 && P<=900){
        Vv=-0.00028*P+0.467;
    }
    else if(P>=900 && P<=950){
        Vv=-0.00022*P+0.413;
    }
    else if(P>=950 && P<=1000){
        Vv=-0.0002*P+0.394;
    }
    return Vv;
}
float LIHl(float P){
    float Hl;
    if(P>=700 && P<=750){
        Hl=0.244*P+526.3;
    }
    else if(P>=750 && P<=800){
        Hl=0.232*P+535.3;
    }
    else if(P>=800 && P<=850){
        Hl=0.222*P+543.3;
    }
    else if(P>=850 && P<=900){
        Hl=0.212*P+551.8;
    }
    else if(P>=900 && P<=950){
        Hl=0.204*P+559.0;
    }
    else if(P>=950 && P<=1000){
        Hl=0.196*P+566.6;
    }
    return Hl;
}
float LIHv(float P){
    float Hv;
    if(P>=700 && P<=800){
        Hv=0.06*P+2720.0;
    }
    else if(P>=800 && P<=1000){
        Hv=0.04*P+2736.0;
    }
    return Hv;
}
float g1(float P, float alpha){
    float Vlsat=LIVl(P), Vvsat=LIVv(P); //find using linear interpolation
    float g1val = alpha*1.0/Vlsat + (1.0-alpha*1.0)*1.0/Vvsat;
    return g1val;
}
float g2(float P, float alpha){
    float Ulsat=LIUl(P), Vlsat=LIVl(P), Uvsat=LIUv(P), Vvsat=LIVv(P); //find using linear interpolation
    float g2val = 1.0*alpha*Ulsat/Vlsat + 1.0*(1.0-alpha)*Uvsat/Vvsat;
    return g2val;
}
int main(){
    ifstream myfile;
    myfile.open("input1.txt");
    float Pi, Pf, alphai, alphaf, a, b, test, Vacc, m1dot, m2dot, deltat, P1, P2;
    myfile>>Pi>>alphai>>alphaf>>m1dot>>m2dot>>deltat>>P1>>P2;
    a = 1.0*(m1dot - m2dot)*deltat;
    b = 1.0*(m1dot*LIHv(P1) - m2dot*LIHv(P2))*deltat;
    for(Pf=P2+100; Pf<=P1-50; ){
        test = (g2(Pf, alphaf)*1.0 - 1.0*g2(Pi, alphai))/(1.0*g1(Pf, alphaf) - 1.0*g1(Pi, alphai));
        //cout<<test<<" "<<1.0*b/a<<endl;
        if(test - 1.0*b/a<=20 && test - 1.0*b/a >= -20.0){
            break;
        }
        Pf+=1;
    }
    if(Pf<=P1-50 && Pf>=P2+100){
        Vacc = 1.0*a/(g1(Pf, alphaf) - g1(Pi, alphai));
        cout<<Pf<<" "<<Vacc;
    }
    else{
        cout<<"No valid solution";
    }
}